package com.example.coffeeshops

 class CoffeeShop(
    val imageResId: Int,
    val name: String,
    val rating: Float,
    val address: String
)
