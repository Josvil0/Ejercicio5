package com.example.elsol

data class SolarItem(
    var name: String,
    val imageResId: Int
)
