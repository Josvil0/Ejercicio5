package com.example.elsol

class Planeta(
    val nombre: String,
    val diametro: Double,
    val distanciaAlSol: Double,
    val densidad: Int
)
